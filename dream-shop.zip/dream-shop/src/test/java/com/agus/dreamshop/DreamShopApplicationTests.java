package com.agus.dreamshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DreamShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
